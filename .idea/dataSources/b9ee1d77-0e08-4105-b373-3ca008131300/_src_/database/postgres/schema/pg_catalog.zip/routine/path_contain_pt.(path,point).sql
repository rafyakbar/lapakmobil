create function pg_catalog.path_contain_pt(path, point) returns boolean
LANGUAGE SQL
AS $$
select pg_catalog.on_ppath($2, $1)
$$;
